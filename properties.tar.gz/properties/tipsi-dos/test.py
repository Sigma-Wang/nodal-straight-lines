#! /usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt

import tbplas as tb
from tbplas import gen_kpath, wan2pc


cell = wan2pc("wannier90", hop_eng_cutoff=0.001)
lat_sc = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]])

cell2 = tb.reshape_prim_cell(cell, lat_sc)
super_cell_pbc = tb.SuperCell(cell2, dim=(1, 1, 1), pbc=(True, True, True))
sample_pbc = tb.Sample(super_cell_pbc)

k_mesh = tb.gen_kmesh((100, 100, 100))
energies, dos = sample_pbc.calc_dos(k_mesh,e_step=0.002,sigma=0.002)
np.savetxt("dos.dat",np.column_stack((energies,dos)))

