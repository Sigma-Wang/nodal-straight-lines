#! /usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt

import tbplas as tb
from tbplas import gen_kpath, wan2pc


cell = wan2pc("wannier90", hop_eng_cutoff=0.005)
#cell.lat()
#cell.plot()
lat_sc = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]])
cell2 = tb.reshape_prim_cell(cell, lat_sc)
#cell2.plot()


#super_cell_pbc = tb.SuperCell(cell2, dim=(800, 800, 30), pbc=(True, True, False))
super_cell_pbc = tb.SuperCell(cell2, dim=(1, 1, 10), pbc=(True, True, False))
sample_pbc = tb.Sample(super_cell_pbc)
 
# Then we set up the parameters governing the TBPM calculation.
# We will use 4 random samples. For each sample 256 the propagation will take
# 256 steps. The DOS will be evaluated on the energy range of [-10, 10] eV.
 
# Then we create a solver and an analyzer from sample and configuration.
k_points = np.array([
    [0.0, 0.0, 0.0],
    [0.5, 0.0, 0.0],
    [0.0, 0.0, 0.0],
])
k_path, k_idx = gen_kpath(k_points, [130, 130])
k_len, bands = sample_pbc.calc_bands(k_path)
f = open('band.dat', 'w')
for i in range(40):
    for j in range(260):
        output = str('%f' % k_len[j])+"  "+str('%f' % bands[j][i])+'\n'
        f.write(output)
    f.write('\n')
f.close()

