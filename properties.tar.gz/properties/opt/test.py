#! /usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt

import tbplas as tb
from tbplas import gen_kpath, wan2pc


cell = wan2pc("wannier90", hop_eng_cutoff=0.005)
#cell.lat()
#cell.plot()
lat_sc = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]])
cell2 = tb.reshape_prim_cell(cell, lat_sc)
#cell2.plot()


#super_cell_pbc = tb.SuperCell(cell2, dim=(800, 800, 30), pbc=(True, True, False))
super_cell_pbc = tb.SuperCell(cell2, dim=(400, 400, 8), pbc=(True, True, False))
#super_cell_pbc = tb.SuperCell(cell2, dim=(800, 800, 5), pbc=(True, True, False))
sample_pbc = tb.Sample(super_cell_pbc)
#sample_pbc.init_hop()
#hop_bak=sample_pbc.hop_v.copy()
#sample_pbc.set_magnetic_field(0.0)
#print(hop_bak-sample_pbc.hop_v)
sample_pbc.rescale_ham(0.6)
 
# Then we set up the parameters governing the TBPM calculation.
# We will use 4 random samples. For each sample 256 the propagation will take
# 256 steps. The DOS will be evaluated on the energy range of [-10, 10] eV.
config = tb.Config()
config.generic['nr_random_samples'] = 4
#config.generic['nr_time_steps'] = 3072
config.generic['nr_time_steps'] = 2048
#config.generic['energy_range'] = 1.2
 
# Then we create a solver and an analyzer from sample and configuration.
#solver = tb.Solver(sample_pbc, config)
solver = tb.Solver(sample_pbc, config, enable_mpi=True)
#analyzer = tb.Analyzer(sample_pbc, config)
analyzer = tb.Analyzer(sample_pbc, config, enable_mpi=True)

# Get AC conductivity
corr_ac = solver.calc_corr_ac_cond()
omegas_ac, ac = analyzer.calc_ac_cond(corr_ac)
if analyzer.is_master:
    np.savetxt("opt.dat-2048",np.column_stack((omegas_ac,ac[0])))
    #np.savetxt("opt.dat-3072",np.column_stack((omegas_ac,ac[0])))

