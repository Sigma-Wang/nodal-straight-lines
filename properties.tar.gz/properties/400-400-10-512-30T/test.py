#! /usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt

import tbplas as tb
from tbplas import gen_kpath, wan2pc


cell = wan2pc("wannier90", hop_eng_cutoff=0.005)
#cell.lat()
#cell.plot()
lat_sc = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]])
cell2 = tb.reshape_prim_cell(cell, lat_sc)
#cell2.plot()


#super_cell_pbc = tb.SuperCell(cell2, dim=(800, 800, 30), pbc=(True, True, False))
super_cell_pbc = tb.SuperCell(cell2, dim=(400, 400, 10), pbc=(True, True, False))
sample_pbc = tb.Sample(super_cell_pbc)
#sample_pbc.init_hop()
#hop_bak=sample_pbc.hop_v.copy()
sample_pbc.set_magnetic_field(30.0)
#print(hop_bak-sample_pbc.hop_v)
sample_pbc.rescale_ham(0.6)
 
# Then we set up the parameters governing the TBPM calculation.
# We will use 4 random samples. For each sample 256 the propagation will take
# 256 steps. The DOS will be evaluated on the energy range of [-10, 10] eV.
config = tb.Config()
config.generic['nr_random_samples'] = 4
config.generic['nr_time_steps'] = 512
#config.generic['energy_range'] = 1.2
 
# Then we create a solver and an analyzer from sample and configuration.
#solver = tb.Solver(sample_pbc, config)
solver = tb.Solver(sample_pbc, config, enable_mpi=True)
#analyzer = tb.Analyzer(sample_pbc, config)
analyzer = tb.Analyzer(sample_pbc, config, enable_mpi=True)
 
# Get DOS correlation function with solver.
corr_dos = solver.calc_corr_dos()
 
# Analyze DOS correlation function with analyzer.
energies_dos, dos = analyzer.calc_dos(corr_dos)
#energies_dos=energies_dos-2.3 
if analyzer.is_master:
    np.savetxt("dos.dat",np.column_stack((energies_dos,dos)))
#np.savetxt("tipsi-0T-slab2-1024.dat",np.column_stack((energies_dos,dos)))
#np.savetxt("dos-test.dat",np.column_stack((energies_dos,dos)))











#k_points = np.array([
#    [0.0, 0.0, 0.0],
#    [0.5, 0.0, 0.0],
#    [0.0, 0.0, 0.0],
#])
#k_path, k_idx = gen_kpath(k_points, [130, 130])
#k_len, bands = sample_pbc.calc_bands(k_path)
#f = open('band.dat', 'w')
#for i in range(40):
#    for j in range(260):
#        output = str('%f' % k_len[j])+"  "+str('%f' % bands[j][i])+'\n'
#        f.write(output)
#    f.write('\n')
#f.close()

#k_mesh = tb.gen_kmesh((500, 500, 5))
#energies, dos = sample_pbc.calc_dos(k_mesh,e_step=0.001,sigma=0.001)
#np.savetxt("dos.dat",np.column_stack((energies,dos)))
#np.savetxt("slab-dos.dat",np.column_stack((energies,dos)))

